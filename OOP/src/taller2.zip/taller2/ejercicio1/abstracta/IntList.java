package taller2.ejercicio1.abstracta;

public interface IntList {
	public void add(int e);
	public void remove();
	public int get(int index);
	public int size();
}
