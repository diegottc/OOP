package taller2.profe.parte2;

public class Pepperoni extends Ingredient {
	public Pepperoni(){
	  super.name = "pepperoni";
	  super.calories = 495;
	  super.price = 10;
  }
}
