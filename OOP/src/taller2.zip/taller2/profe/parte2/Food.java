package taller2.profe.parte2;

public interface Food {
	String getName();
	int getCalories();
	int getPrice();
}
