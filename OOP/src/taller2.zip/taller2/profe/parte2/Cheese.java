package taller2.profe.parte2;

public class Cheese extends Ingredient {
	public Cheese(){
	  super.name = "cheese";
	  super.calories = 299;
	  super.price = 3;
  }
}
