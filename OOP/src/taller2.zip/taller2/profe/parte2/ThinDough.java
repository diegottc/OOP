package taller2.profe.parte2;

public class ThinDough extends Pizza {
	public ThinDough(){
		  super.name = "thin dough";
		  super.calories = 50;
		  super.price = 3;
	  }
}
