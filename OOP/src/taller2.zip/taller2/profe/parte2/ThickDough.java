package taller2.profe.parte2;

public class ThickDough extends Pizza {
	public ThickDough(){
		  super.name = "thick dough";
		  super.calories = 100;
		  super.price = 5;
	  }
}
