package taller2.profe.parte2;

public class Tomato extends Ingredient {
	public Tomato(){
	  super.name = "tomato";
	  super.calories = 15;
	  super.price = 2;
  }
}
