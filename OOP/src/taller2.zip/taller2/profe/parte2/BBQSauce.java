package taller2.profe.parte2;

public class BBQSauce extends Ingredient {
	public BBQSauce(){
	  super.name = "bbq sauce";
	  super.calories = 194;
	  super.price = 1;
  }
}
