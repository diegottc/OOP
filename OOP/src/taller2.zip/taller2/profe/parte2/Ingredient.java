package taller2.profe.parte2;


public abstract class Ingredient extends AbstractFood{}
