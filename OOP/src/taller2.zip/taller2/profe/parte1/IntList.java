package taller2.profe.parte1;

public interface IntList  {
	
	void add(int n);
	void addAtBegin(int n);
	void remove();
	int get(int i);
	int size();
	
}
